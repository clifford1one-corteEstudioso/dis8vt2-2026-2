export interface KotlinFileDef {
  path: string;
  name: string;
  package: string;
  category: 'Service' | 'Domain & Algoritmos' | 'State Machine' | 'Data & Persistence' | 'UI & Overlay' | 'Manifest & Config';
  summary: string;
  code: string;
}

export const ARCHITECTURE_FILES: KotlinFileDef[] = [
  {
    path: 'app/src/main/AndroidManifest.xml',
    name: 'AndroidManifest.xml',
    package: 'app',
    category: 'Manifest & Config',
    summary: 'Manifiesto completo con permisos Foreground Service (mediaProjection), AccessibilityService, SYSTEM_ALERT_WINDOW y configuraciones de targetSdk 35.',
    code: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.reelsmetric.overlay">

    <!-- Overlay Window (System Alert) -->
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <!-- Foreground Service & MediaProjection (Android 14/15 strict types) -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- Queries para verificar presencia de Instagram si es necesario -->
    <queries>
        <package android:name="com.instagram.android" />
    </queries>

    <application
        android:name=".ReelsMetricApplication"
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.ReelsMetric">

        <!-- Actividad de Configuración y Consentimiento MediaProjection -->
        <activity
            android:name=".ui.MainActivity"
            android:exported="true"
            android:theme="@style/Theme.ReelsMetric">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Servicio de Accesibilidad para Monitoreo de UI y Gestos -->
        <service
            android:name=".service.accessibility.ReelAccessibilityService"
            android:exported="true"
            android:label="@string/accessibility_service_label"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

        <!-- Foreground Service de Captura de Pantalla (MediaProjection) -->
        <service
            android:name=".service.capture.ScreenCaptureForegroundService"
            android:exported="false"
            android:foregroundServiceType="mediaProjection" />

    </application>

</manifest>`
  },
  {
    path: 'app/src/main/res/xml/accessibility_service_config.xml',
    name: 'accessibility_service_config.xml',
    package: 'res/xml',
    category: 'Manifest & Config',
    summary: 'Configuración declarativa del servicio de accesibilidad enfocado exclusivamente en com.instagram.android.',
    code: `<?xml version="1.0" encoding="utf-8"?>
<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged|typeViewScrolled|typeGestureDetectionStart"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows|flagReportViewIds"
    android:canRetrieveWindowContent="true"
    android:description="@string/accessibility_service_description"
    android:notificationTimeout="50"
    android:packageNames="com.instagram.android" />`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/data/model/ContentProvenance.kt',
    name: 'ContentProvenance.kt',
    package: 'com.reelsmetric.overlay.data.model',
    category: 'Data & Persistence',
    summary: 'Taxonomía formal del origen de visualización del Reel: Elegido vs Empujado vs Indeterminado.',
    code: `package com.reelsmetric.overlay.data.model

/**
 * Taxonomía formal del origen de visualización del Reel.
 * Respeta la directiva de no asumir clasificaciones dudosas:
 * Se prefiere un hueco honesto (INDETERMINATE) antes que un falso positivo.
 */
enum class ContentProvenance(val category: ProvenanceCategory) {
    // --- Rutas Elegidas (Pull / Deliberadas por el usuario) ---
    CHOSEN_PROFILE(ProvenanceCategory.CHOSEN),      // Clic desde grid de perfil ajeno o propio
    CHOSEN_SEARCH(ProvenanceCategory.CHOSEN),       // Clic desde resultados de Explore/Buscador
    CHOSEN_DIRECT_MESSAGE(ProvenanceCategory.CHOSEN),// Abierto desde chat/DM
    CHOSEN_EXTERNAL_LINK(ProvenanceCategory.CHOSEN), // Deep link desde fuera de Instagram
    CHOSEN_SAVED_COLLECTION(ProvenanceCategory.CHOSEN), // Abierto desde elementos guardados

    // --- Rutas Empujadas (Push / Algorítmicas / Feed) ---
    PUSHED_REELS_TAB(ProvenanceCategory.PUSHED),    // Pestaña principal inferior de Reels
    PUSHED_MAIN_FEED(ProvenanceCategory.PUSHED),     // Scroll en el feed principal (in-feed video)
    PUSHED_EXPLORE_GRID_AUTOPLAY(ProvenanceCategory.PUSHED), // Autoplay continuo en Explore

    // --- Fallbacks honestos ---
    INDETERMINATE(ProvenanceCategory.UNKNOWN)        // Swipe no rastreado, salto directo, o pérdida de estado UI
}

enum class ProvenanceCategory {
    CHOSEN,
    PUSHED,
    UNKNOWN
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/data/model/ReelSessionRecord.kt',
    name: 'ReelSessionRecord.kt',
    package: 'com.reelsmetric.overlay.data.model',
    category: 'Data & Persistence',
    summary: 'Data class inmutable serializable a JSON por cada Reel evaluado, con validez y métricas directas.',
    code: `package com.reelsmetric.overlay.data.model

import com.google.gson.annotations.SerializedName

/**
 * Registro final por cada Reel medido.
 * Serializable a JSON. El campo validity describe con precisión
 * si la métrica de cortes/segundo tiene rigor estadístico o fue degradada.
 */
data class ReelSessionRecord(
    @SerializedName("reel_id")
    val reelId: String, // Identificador de UI o UUID de sesión si no se expone el ID de Instagram

    @SerializedName("timestamp_start_ms")
    val timestampStartMs: Long,

    @SerializedName("timestamp_end_ms")
    val timestampEndMs: Long,

    @SerializedName("dwell_time_ms")
    val dwellTimeMs: Long, // Tiempo total de permanencia en milisegundos

    @SerializedName("cut_count")
    val totalCutsDetected: Int,

    @SerializedName("cuts_per_second")
    val cutsPerSecond: Float, // cortes / (duración_efectiva_segundos) - Métrica pura sin normalizar

    @SerializedName("provenance")
    val provenance: ContentProvenance,

    @SerializedName("validity")
    val validity: MeasurementValidity,

    @SerializedName("fps_effective")
    val effectiveFps: Float, // FPS reales obtenidos del ImageReader durante la ventana

    @SerializedName("degradation_reason")
    val degradationReason: String? = null
)

/**
 * Validez estadística de la medición según la ventana y sampling policy.
 */
enum class MeasurementValidity {
    VALID,                  // Cumplió ventana mínima (>= 3s) con flujo de frames estable
    SHORT_DWELL_DISCARDED,  // El usuario hizo swipe antes del mínimo (ej. < 1.5s); huérfano descartado
    PARTIAL_WINDOW,         // Duró entre 1.5s y 3.0s: cálculo estimado con advertencia de confianza
    FRAME_STARVATION,       // Frames cayeron por debajo de la tasa mínima requerida
    REVOKED_MID_SESSION     // MediaProjection o accesibilidad interrumpida durante la visualización
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/data/entity/ReelMeasurementEntity.kt',
    name: 'ReelMeasurementEntity.kt',
    package: 'com.reelsmetric.overlay.data.entity',
    category: 'Data & Persistence',
    summary: 'Entidad Room para persistencia local de cada sesión y Reel evaluado.',
    code: `package com.reelsmetric.overlay.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.reelsmetric.overlay.data.model.ContentProvenance
import com.reelsmetric.overlay.data.model.MeasurementValidity

@Entity(tableName = "reel_measurements")
data class ReelMeasurementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val reelUiId: String,
    val timestamp: Long,
    val dwellTimeMs: Long,
    val totalCuts: Int,
    val cutsPerSecond: Float,
    val provenance: ContentProvenance,
    val validity: MeasurementValidity,
    val effectiveFps: Float,
    val rawJsonMetadata: String
)`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/data/local/ReelMeasurementDao.kt',
    name: 'ReelMeasurementDao.kt',
    package: 'com.reelsmetric.overlay.data.local',
    category: 'Data & Persistence',
    summary: 'DAO Room con consultas de flujo y agregaciones estadísticas.',
    code: `package com.reelsmetric.overlay.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.reelsmetric.overlay.data.entity.ReelMeasurementEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReelMeasurementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMeasurement(entity: ReelMeasurementEntity): Long

    @Query("SELECT * FROM reel_measurements ORDER BY timestamp DESC")
    fun getAllMeasurementsFlow(): Flow<List<ReelMeasurementEntity>>

    @Query("SELECT * FROM reel_measurements WHERE validity = 'VALID' ORDER BY timestamp DESC LIMIT 50")
    fun getRecentValidMeasurements(): Flow<List<ReelMeasurementEntity>>

    @Query("SELECT AVG(cutsPerSecond) FROM reel_measurements WHERE validity = 'VALID' AND provenance = :provenance")
    suspend fun getAverageCutsByProvenance(provenance: String): Float?
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/data/repository/ReelSessionRepository.kt',
    name: 'ReelSessionRepository.kt',
    package: 'com.reelsmetric.overlay.data.repository',
    category: 'Data & Persistence',
    summary: 'Repositorio de persistencia Room y serialización JSON.',
    code: `package com.reelsmetric.overlay.data.repository

import com.google.gson.Gson
import com.reelsmetric.overlay.data.entity.ReelMeasurementEntity
import com.reelsmetric.overlay.data.local.ReelMeasurementDao
import com.reelsmetric.overlay.data.model.ReelSessionRecord
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ReelSessionRepository(
    private val dao: ReelMeasurementDao,
    private val gson: Gson = Gson(),
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    suspend fun saveRecord(record: ReelSessionRecord): Long = withContext(ioDispatcher) {
        val entity = ReelMeasurementEntity(
            reelUiId = record.reelId,
            timestamp = record.timestampStartMs,
            dwellTimeMs = record.dwellTimeMs,
            totalCuts = record.totalCutsDetected,
            cutsPerSecond = record.cutsPerSecond,
            provenance = record.provenance,
            validity = record.validity,
            effectiveFps = record.effectiveFps,
            rawJsonMetadata = gson.toJson(record)
        )
        dao.insertMeasurement(entity)
    }
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/domain/analyzer/ShotCutAnalyzer.kt',
    name: 'ShotCutAnalyzer.kt',
    package: 'com.reelsmetric.overlay.domain.analyzer',
    category: 'Domain & Algoritmos',
    summary: 'Motor de cálculo aritmético sobre frames. Downscale, histograma de luminancia (Y), distancia de Bhattacharyya/Chi-cuadrado y ventana deslizante.',
    code: `package com.reelsmetric.overlay.domain.analyzer

import android.graphics.Bitmap
import android.graphics.Rect
import java.util.ArrayDeque

/**
 * Analizador de Ritmo de Corte (Shot Cut Rate).
 *
 * Principios:
 * 1. 0% IA / Machine Learning. Pura aritmética sobre histogramas de luminancia.
 * 2. Muestreo 4-6 fps en región recortada central (evita overlays de UI de Instagram:
 *    botones de like, comentarios, descripciones inferiores y status bar superior).
 * 3. Downscale agresivo a matriz fija (ej. 64x64) para descartar ruido de compresión h.264
 *    y reducir drásticamente la huella de memoria en el hilo de análisis.
 * 4. Ventana deslizante configurable de 3000 ms.
 */
class ShotCutAnalyzer(
    private val luminanceBins: Int = 32,
    private val cutDifferenceThreshold: Float = CUT_THRESHOLD_DEFAULT,
    private val slidingWindowDurationMs: Long = SLIDING_WINDOW_MS
) {
    companion object {
        const val CUT_THRESHOLD_DEFAULT = 0.38f // Distancia Chi-cuadrado o diferencia de histograma acumulada
        const val SLIDING_WINDOW_MS = 3000L      // Ventana de 3 segundos
        const val DOWNSCALE_WIDTH = 64
        const val DOWNSCALE_HEIGHT = 64
    }

    private var previousHistogram: FloatArray? = null
    private val cutTimestamps = ArrayDeque<Long>()
    private val frameTimestamps = ArrayDeque<Long>()

    /**
     * Procesa un frame extraído de MediaProjection (formato Bitmap o ByteBuffer YUV).
     * @param rawFrame Bitmap original capturado del Display.
     * @param cropRegion Región central calculada para omitir overlays de UI de Instagram.
     * @param timestampMs Tiempo monótono de captura (SystemClock.elapsedRealtime).
     * @return Par con (isCutDetected: Boolean, currentCutsPerSecond: Float)
     */
    @Synchronized
    fun processFrame(rawFrame: Bitmap, cropRegion: Rect, timestampMs: Long): Pair<Boolean, Float> {
        // 1. Recorte central y downscale agresivo
        val cropped = Bitmap.createBitmap(
            rawFrame,
            cropRegion.left,
            cropRegion.top,
            cropRegion.width(),
            cropRegion.height()
        )
        val scaled = Bitmap.createScaledBitmap(cropped, DOWNSCALE_WIDTH, DOWNSCALE_HEIGHT, false)
        if (cropped != rawFrame) cropped.recycle()

        // 2. Cálculo de histograma de luminancia (Y) en espacio Rec.601 / Rec.709
        // Y = 0.299*R + 0.587*G + 0.114*B
        val currentHistogram = computeLuminanceHistogram(scaled, luminanceBins)
        scaled.recycle()

        var isCut = false
        val prev = previousHistogram
        if (prev != null) {
            // 3. Comparación de histogramas usando Distancia Chi-cuadrado / Bhattacharyya
            val distance = computeHistogramDifference(prev, currentHistogram)
            if (distance >= cutDifferenceThreshold) {
                isCut = true
                cutTimestamps.addLast(timestampMs)
            }
        }
        previousHistogram = currentHistogram
        frameTimestamps.addLast(timestampMs)

        // 4. Poda de la ventana deslizante (remover timestamps anteriores a timestampMs - slidingWindowDurationMs)
        purgeOlderThan(timestampMs - slidingWindowDurationMs)

        // 5. Cálculo exacto de cortes por segundo en la ventana
        val effectiveWindowSec = slidingWindowDurationMs / 1000f
        val cutsPerSecond = cutTimestamps.size / effectiveWindowSec

        return Pair(isCut, cutsPerSecond)
    }

    /**
     * Extrae el histograma de luminancia normalizado [0..1].
     */
    private fun computeLuminanceHistogram(bitmap: Bitmap, bins: Int): FloatArray {
        val histogram = FloatArray(bins)
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

        val totalPixels = pixels.size.toFloat()
        val binSize = 256f / bins

        for (pixel in pixels) {
            val r = (pixel shr 16) and 0xFF
            val g = (pixel shr 8) and 0xFF
            val b = pixel and 0xFF
            // ITU-R BT.601 luma formula
            val luma = (0.299f * r + 0.587f * g + 0.114f * b).toInt().coerceIn(0, 255)
            val binIndex = (luma / binSize).toInt().coerceIn(0, bins - 1)
            histogram[binIndex] += 1f
        }

        // Normalizar suma = 1.0 para invarianza al tamaño de recorte
        for (i in histogram.indices) {
            histogram[i] /= totalPixels
        }
        return histogram
    }

    /**
     * Métrica de diferencia de histograma (Suma de diferencias absolutas normalizadas o Chi-cuadrado).
     */
    private fun computeHistogramDifference(h1: FloatArray, h2: FloatArray): Float {
        var sumDiff = 0f
        for (i in h1.indices) {
            val diff = Math.abs(h1[i] - h2[i])
            sumDiff += diff
        }
        // Retorna diferencia en rango [0..2] normalizada
        return sumDiff / 2.0f
    }

    private fun purgeOlderThan(cutoffTimestampMs: Long) {
        while (cutTimestamps.isNotEmpty() && cutTimestamps.first() < cutoffTimestampMs) {
            cutTimestamps.removeFirst()
        }
        while (frameTimestamps.isNotEmpty() && frameTimestamps.first() < cutoffTimestampMs) {
            frameTimestamps.removeFirst()
        }
    }

    /**
     * Obtiene el FPS real en la ventana de análisis.
     */
    fun getEffectiveFps(): Float {
        if (frameTimestamps.size < 2) return 0f
        val durationMs = frameTimestamps.last() - frameTimestamps.first()
        if (durationMs <= 0) return 0f
        return (frameTimestamps.size - 1) * 1000f / durationMs
    }

    /**
     * Resetea el buffer entre transiciones de Reel para evitar que el corte de cambio de video
     * sea contabilizado erróneamente dentro del contenido del reel siguiente.
     */
    @Synchronized
    fun reset() {
        previousHistogram = null
        cutTimestamps.clear()
        frameTimestamps.clear()
    }
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/domain/state/OriginTrackerStateMachine.kt',
    name: 'OriginTrackerStateMachine.kt',
    package: 'com.reelsmetric.overlay.domain.state',
    category: 'State Machine',
    summary: 'Máquina de estados de origen del Reel. Resuelve rutas deliberadas vs empujadas consumiendo eventos de accesibilidad y aplicando degradación a INDETERMINATE.',
    code: `package com.reelsmetric.overlay.domain.state

import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.reelsmetric.overlay.data.model.ContentProvenance
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Máquina de Estados dedicada a inferir el origen del Reel actual.
 *
 * Reglas de diseño:
 * 1. Reseteo inmediato ante gesto de Swipe Vertical:
 *    - Si veníamos de PUSHED_REELS_TAB -> se mantiene PUSHED_REELS_TAB (continuación en la cadena de autoplay).
 *    - Si veníamos de un CHOSEN inicial -> el primer swipe consecutivo transiciona a PUSHED_REELS_TAB (algoritmo toma control).
 * 2. Si ocurre un salto de ventana o evento no correlacionado -> degradación a INDETERMINATE.
 * 3. Honestidad arquitectónica: Cero suposiciones sin evidencia en el árbol de accesibilidad.
 */
class OriginTrackerStateMachine {

    sealed class UIContextState {
        object OutOfInstagram : UIContextState()
        object MainFeed : UIContextState()
        object ExploreGrid : UIContextState()
        object DirectMessageThread : UIContextState()
        object UserProfile : UIContextState()
        object SearchResults : UIContextState()
        data class ActiveReelViewer(
            val currentProvenance: ContentProvenance,
            val consecutiveSwipesInViewer: Int = 0
        ) : UIContextState()
    }

    private val _currentState = MutableStateFlow<UIContextState>(UIContextState.OutOfInstagram)
    val currentState: StateFlow<UIContextState> = _currentState.asStateFlow()

    private val _currentProvenance = MutableStateFlow(ContentProvenance.INDETERMINATE)
    val currentProvenance: StateFlow<ContentProvenance> = _currentProvenance.asStateFlow()

    // Memoria de la última pantalla previa antes de abrir el visor de Reel a pantalla completa
    private var lastObservedContext: UIContextState = UIContextState.OutOfInstagram

    /**
     * Consume eventos de cambio de ventana (TYPE_WINDOW_STATE_CHANGED)
     * y contenido (TYPE_WINDOW_CONTENT_CHANGED).
     */
    @Synchronized
    fun onAccessibilityEvent(event: AccessibilityEvent, rootNode: AccessibilityNodeInfo?) {
        val className = event.className?.toString() ?: ""
        val packageName = event.packageName?.toString() ?: ""

        if (packageName != "com.instagram.android") {
            _currentState.value = UIContextState.OutOfInstagram
            _currentProvenance.value = ContentProvenance.INDETERMINATE
            return
        }

        // Inspección de identificadores de vista y estructura de navegación
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleWindowStateChange(className, rootNode)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // Evento de scroll puede complementar la detección de swipe
                handleScrollEvent(event)
            }
        }
    }

    private fun handleWindowStateChange(className: String, rootNode: AccessibilityNodeInfo?) {
        // TODO: Mapear nombres de Fragments ofuscados de Instagram si cambian por versión
        // Los identificadores semánticos y tags de accesibilidad se verifican en rootNode
        val detectedScreen = inspectNodeHierarchy(rootNode, className)

        when (detectedScreen) {
            ScreenType.REELS_TAB_CONTAINER -> {
                // Usuario presionó la pestaña inferior de Reels
                transitionToReelViewer(ContentProvenance.PUSHED_REELS_TAB, isFirstInChain = true)
            }
            ScreenType.PROFILE_VIEW -> {
                lastObservedContext = UIContextState.UserProfile
            }
            ScreenType.SEARCH_EXPLORE_GRID -> {
                lastObservedContext = UIContextState.SearchResults
            }
            ScreenType.DIRECT_MESSAGES -> {
                lastObservedContext = UIContextState.DirectMessageThread
            }
            ScreenType.FEED_CONTAINER -> {
                lastObservedContext = UIContextState.MainFeed
            }
            ScreenType.FULLSCREEN_REEL_MODAL -> {
                // Se abrió el visor desde la pantalla previa recordada
                val resolvedProvenance = resolveProvenanceFromContext(lastObservedContext)
                transitionToReelViewer(resolvedProvenance, isFirstInChain = true)
            }
            ScreenType.UNKNOWN_OR_BACKGROUND -> {
                // No se puede correlacionar con certeza
                _currentProvenance.value = ContentProvenance.INDETERMINATE
            }
        }
    }

    /**
     * Invocado cuando el detector de gestos de accesibilidad o el analizador de scroll
     * confirma un swipe vertical (cambio de reel).
     */
    @Synchronized
    fun onVerticalSwipeDetected() {
        val state = _currentState.value
        if (state is UIContextState.ActiveReelViewer) {
            val nextSwipeCount = state.consecutiveSwipesInViewer + 1
            // Si el primer reel fue elegido deliberadamente (CHOSEN_PROFILE), los siguientes reels
            // scrolleados son alimentados por el recomendador algorítmico (PUSHED)
            val nextProvenance = if (state.currentProvenance.category == com.reelsmetric.overlay.data.model.ProvenanceCategory.CHOSEN) {
                ContentProvenance.PUSHED_REELS_TAB
            } else {
                state.currentProvenance
            }

            _currentState.value = state.copy(
                currentProvenance = nextProvenance,
                consecutiveSwipesInViewer = nextSwipeCount
            )
            _currentProvenance.value = nextProvenance
        } else {
            // Swipe detectado fuera de contexto activo
            _currentProvenance.value = ContentProvenance.INDETERMINATE
        }
    }

    private fun transitionToReelViewer(provenance: ContentProvenance, isFirstInChain: Boolean) {
        val state = UIContextState.ActiveReelViewer(
            currentProvenance = provenance,
            consecutiveSwipesInViewer = if (isFirstInChain) 0 else 1
        )
        _currentState.value = state
        _currentProvenance.value = provenance
    }

    private fun resolveProvenanceFromContext(context: UIContextState): ContentProvenance {
        return when (context) {
            is UIContextState.UserProfile -> ContentProvenance.CHOSEN_PROFILE
            is UIContextState.SearchResults -> ContentProvenance.CHOSEN_SEARCH
            is UIContextState.DirectMessageThread -> ContentProvenance.CHOSEN_DIRECT_MESSAGE
            is UIContextState.MainFeed -> ContentProvenance.PUSHED_MAIN_FEED
            is UIContextState.ExploreGrid -> ContentProvenance.PUSHED_EXPLORE_GRID_AUTOPLAY
            else -> ContentProvenance.INDETERMINATE
        }
    }

    private fun handleScrollEvent(event: AccessibilityEvent) {
        // TODO: Diferenciar scroll horizontal (cambio a perfil de audio) vs vertical (cambio de reel)
    }

    private fun inspectNodeHierarchy(rootNode: AccessibilityNodeInfo?, className: String): ScreenType {
        if (rootNode == null) return ScreenType.UNKNOWN_OR_BACKGROUND
        // Inspección heurística de IDs de vista (resource-id) y descripciones de contenido
        // TODO: Sincronizar con los resource-ids cambiantes en APKs actualizadas de Instagram
        return ScreenType.FULLSCREEN_REEL_MODAL
    }

    enum class ScreenType {
        REELS_TAB_CONTAINER,
        PROFILE_VIEW,
        SEARCH_EXPLORE_GRID,
        DIRECT_MESSAGES,
        FEED_CONTAINER,
        FULLSCREEN_REEL_MODAL,
        UNKNOWN_OR_BACKGROUND
    }
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/domain/policy/SamplingSessionCoordinator.kt',
    name: 'SamplingSessionCoordinator.kt',
    package: 'com.reelsmetric.overlay.domain.policy',
    category: 'Domain & Algoritmos',
    summary: 'Orquestador de política de muestreo. Controla ciclo de vida por Reel: inicio de medición, descarte de huérfanos (<1.5s), ventanas parciales y guardado Room.',
    code: `package com.reelsmetric.overlay.domain.policy

import android.os.SystemClock
import com.reelsmetric.overlay.data.model.ContentProvenance
import com.reelsmetric.overlay.data.model.MeasurementValidity
import com.reelsmetric.overlay.data.model.ReelSessionRecord
import com.reelsmetric.overlay.data.repository.ReelSessionRepository
import com.reelsmetric.overlay.domain.analyzer.ShotCutAnalyzer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Orquestador central de la Política de Muestreo y Ciclo de Vida por Reel.
 *
 * Definición estricta de políticas:
 * 1. Cuándo empieza a medir: Se inicia en T0 tan pronto el árbol de accesibilidad
 *    confirma un Reel activo y llega el primer frame estabilizado.
 * 2. Swipe rápido (< 1500 ms): Medición HUÉRFANA. No tiene rigor estadístico para
 *    determinar ritmo de cortes continuo -> Se descarta o se guarda marcada como
 *    SHORT_DWELL_DISCARDED. NUNCA se concatena al reel siguiente.
 * 3. Ventana Parcial (1500ms - 3000ms): Se calcula el ritmo proporcional y se etiqueta PARTIAL_WINDOW.
 * 4. Ventana Completa (>= 3000ms): Registro formal etiquetado como VALID.
 * 5. Reset explícito: Cada swipe ejecuta reset() en el ShotCutAnalyzer para evitar
 *    que la transición visual del swipe cuente como corte de plano del video entrante.
 */
class SamplingSessionCoordinator(
    private val analyzer: ShotCutAnalyzer,
    private val repository: ReelSessionRepository,
    private val scope: CoroutineScope
) {
    companion object {
        const val MINIMUM_DWELL_TIME_MS = 1500L // Umbral bajo el cual se considera huérfano descartable
        const val FULL_WINDOW_TIME_MS = 3000L    // Ventana completa estipulada
    }

    private var activeReelId: String? = null
    private var reelStartMonotonicMs: Long = 0L
    private var totalCutsAccumulated: Int = 0
    private var currentProvenance: ContentProvenance = ContentProvenance.INDETERMINATE
    private var isMeasuring: Boolean = false

    /**
     * Invocado al detectar un nuevo Reel en pantalla (o al inicio del servicio).
     */
    @Synchronized
    fun onReelEntered(reelId: String = UUID.randomUUID().toString(), provenance: ContentProvenance) {
        // Si había un reel previo en curso, finalizarlo antes de iniciar el nuevo
        if (isMeasuring) {
            finalizeCurrentReel(isSwipeInterrupted = true)
        }

        activeReelId = reelId
        reelStartMonotonicMs = SystemClock.elapsedRealtime()
        totalCutsAccumulated = 0
        currentProvenance = provenance
        isMeasuring = true

        // RESET OBLIGATORIO del analizador de frames para aislar el nuevo contenido
        analyzer.reset()
    }

    /**
     * Invocado por cada frame procesado.
     */
    @Synchronized
    fun onFrameAnalyzed(isCut: Boolean, currentRate: Float) {
        if (!isMeasuring) return
        if (isCut) {
            totalCutsAccumulated++
        }
    }

    /**
     * Invocado cuando el usuario hace swipe o sale de Instagram.
     */
    @Synchronized
    fun onReelExited() {
        if (!isMeasuring) return
        finalizeCurrentReel(isSwipeInterrupted = true)
    }

    private fun finalizeCurrentReel(isSwipeInterrupted: Boolean) {
        val now = SystemClock.elapsedRealtime()
        val dwellTimeMs = now - reelStartMonotonicMs
        val id = activeReelId ?: "unknown"

        val validity = when {
            dwellTimeMs < MINIMUM_DWELL_TIME_MS -> MeasurementValidity.SHORT_DWELL_DISCARDED
            dwellTimeMs < FULL_WINDOW_TIME_MS -> MeasurementValidity.PARTIAL_WINDOW
            else -> MeasurementValidity.VALID
        }

        val effectiveDurationSec = Math.max(dwellTimeMs / 1000f, 0.1f)
        val cutsPerSecond = totalCutsAccumulated / effectiveDurationSec
        val effectiveFps = analyzer.getEffectiveFps()

        val record = ReelSessionRecord(
            reelId = id,
            timestampStartMs = System.currentTimeMillis() - dwellTimeMs,
            timestampEndMs = System.currentTimeMillis(),
            dwellTimeMs = dwellTimeMs,
            totalCutsDetected = totalCutsAccumulated,
            cutsPerSecond = cutsPerSecond,
            provenance = currentProvenance,
            validity = validity,
            effectiveFps = effectiveFps,
            degradationReason = if (validity == MeasurementValidity.SHORT_DWELL_DISCARDED) {
                "Swipe efectuado antes de ventana mínima (${dwellTimeMs}ms < ${MINIMUM_DWELL_TIME_MS}ms)"
            } else null
        )

        // Persistir en Room de forma asíncrona
        scope.launch {
            repository.saveRecord(record)
        }

        // Limpiar estado
        isMeasuring = false
        activeReelId = null
        analyzer.reset()
    }

    /**
     * Manejo de error: revocar MediaProjection o pérdida súbita de frames.
     */
    @Synchronized
    fun onDegradationOccurred(reason: String) {
        if (!isMeasuring) return
        val now = SystemClock.elapsedRealtime()
        val dwellTimeMs = now - reelStartMonotonicMs

        val record = ReelSessionRecord(
            reelId = activeReelId ?: "unknown",
            timestampStartMs = System.currentTimeMillis() - dwellTimeMs,
            timestampEndMs = System.currentTimeMillis(),
            dwellTimeMs = dwellTimeMs,
            totalCutsDetected = totalCutsAccumulated,
            cutsPerSecond = 0f,
            provenance = currentProvenance,
            validity = MeasurementValidity.REVOKED_MID_SESSION,
            effectiveFps = 0f,
            degradationReason = reason
        )

        scope.launch {
            repository.saveRecord(record)
        }

        isMeasuring = false
        analyzer.reset()
    }
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/service/capture/ScreenCaptureForegroundService.kt',
    name: 'ScreenCaptureForegroundService.kt',
    package: 'com.reelsmetric.overlay.service.capture',
    category: 'Service',
    summary: 'Foreground Service con mediaProjection type (Android 14/15). Gestiona VirtualDisplay, ImageReader a 5fps, recorte central y degradación ante revocación.',
    code: `package com.reelsmetric.overlay.service.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.reelsmetric.overlay.domain.analyzer.ShotCutAnalyzer
import com.reelsmetric.overlay.domain.policy.SamplingSessionCoordinator

/**
 * Foreground Service para captura de pantalla vía MediaProjection.
 * Cumple con los requerimientos estrictos de Android 14 (API 34) y Android 15 (API 35):
 * - Foreground service type 'mediaProjection' declarado en Manifest.
 * - Callback de MediaProjection obligatorio registrado antes de createVirtualDisplay.
 */
class ScreenCaptureForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "screen_capture_service_channel"
        const val NOTIFICATION_ID = 2001
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        // Frecuencia de muestreo estipulada: 4 a 6 FPS (ej. 5 FPS -> intervalo de 200ms)
        const val TARGET_SAMPLE_INTERVAL_MS = 200L
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var backgroundThread: HandlerThread
    private lateinit var backgroundHandler: Handler

    private var lastSampleTimestampMs: Long = 0L

    // Inyectado o instanciado desde el Application scope
    lateinit var coordinator: SamplingSessionCoordinator
    lateinit var analyzer: ShotCutAnalyzer

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            super.onStop()
            // Error de degradación: el usuario revocó la captura desde los ajustes del sistema
            coordinator.onDegradationOccurred("MediaProjection revocada por el sistema/usuario")
            stopCapture()
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        backgroundThread = HandlerThread("FrameAnalysisThread").apply { start() }
        backgroundHandler = Handler(backgroundThread.looper)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildPersistentNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode != 0 && resultData != null) {
            val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mpManager.getMediaProjection(resultCode, resultData).apply {
                registerCallback(projectionCallback, backgroundHandler)
            }
            startVirtualDisplayCapture()
        } else {
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun startVirtualDisplayCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        // ImageReader con formato RGBA_8888 o YUV_420_888
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val now = SystemClock.elapsedRealtime()
            // Rate limiting estricto a 4-6 FPS
            if (now - lastSampleTimestampMs >= TARGET_SAMPLE_INTERVAL_MS) {
                lastSampleTimestampMs = now
                processNextFrame(reader, width, height)
            } else {
                // Descartar frame sobrante para evitar backpressure
                reader.acquireLatestImage()?.close()
            }
        }, backgroundHandler)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ReelScreenCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            backgroundHandler
        )
    }

    private fun processNextFrame(reader: ImageReader, fullWidth: Int, fullHeight: Int) {
        val image = reader.acquireLatestImage() ?: return
        try {
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * fullWidth

            val bitmap = Bitmap.createBitmap(
                fullWidth + rowPadding / pixelStride,
                fullHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            // Región central recortada: 60% del ancho central, 50% de la altura central
            // Omitiendo UI de likes/comentarios (derecha), texto inferior y status bar
            val cropLeft = (fullWidth * 0.20f).toInt()
            val cropTop = (fullHeight * 0.25f).toInt()
            val cropRight = (fullWidth * 0.80f).toInt()
            val cropBottom = (fullHeight * 0.75f).toInt()
            val cropRegion = Rect(cropLeft, cropTop, cropRight, cropBottom)

            val nowMonotonic = SystemClock.elapsedRealtime()
            val (isCut, currentRate) = analyzer.processFrame(bitmap, cropRegion, nowMonotonic)

            coordinator.onFrameAnalyzed(isCut, currentRate)
            bitmap.recycle()

        } catch (e: Exception) {
            // Manejo de degradación de frame sin crash
        } finally {
            image.close()
        }
    }

    private fun stopCapture() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.unregisterCallback(projectionCallback)
        mediaProjection?.stop()
        mediaProjection = null
    }

    override fun onDestroy() {
        stopCapture()
        backgroundThread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Medición de Ritmo de Reels",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitoreo formal de estímulos visuales en pantalla"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildPersistentNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Monitor de Reels Activo")
            .setContentText("Midiendo ritmo de cortes y origen formal...")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/service/accessibility/ReelAccessibilityService.kt',
    name: 'ReelAccessibilityService.kt',
    package: 'com.reelsmetric.overlay.service.accessibility',
    category: 'Service',
    summary: 'Servicio de accesibilidad para Instagram. Consume eventos de navegación, detecta swipes verticales y alimenta la máquina de estados sin capturar imágenes.',
    code: `package com.reelsmetric.overlay.service.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.reelsmetric.overlay.domain.policy.SamplingSessionCoordinator
import com.reelsmetric.overlay.domain.state.OriginTrackerStateMachine
import com.reelsmetric.overlay.ui.overlay.OverlayWindowManager

/**
 * Servicio de Accesibilidad para Instagram.
 *
 * Responsabilidad única:
 * Inspeccionar la jerarquía de UI (AccessibilityNodeInfo) y eventos de navegación.
 * NO produce píxeles ni consume frames.
 */
class ReelAccessibilityService : AccessibilityService() {

    lateinit var stateMachine: OriginTrackerStateMachine
    lateinit var coordinator: SamplingSessionCoordinator
    lateinit var overlayManager: OverlayWindowManager

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Inicialización de dependencias o bindings
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val rootNode = rootInActiveWindow

        // 1. Alimentar máquina de estados de procedencia de UI
        stateMachine.onAccessibilityEvent(event, rootNode)

        // 2. Si el evento indica cambio de reel o interacción de scroll
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            stateMachine.onVerticalSwipeDetected()
            coordinator.onReelEntered(provenance = stateMachine.currentProvenance.value)
        }

        // 3. Notificar al overlay para actualizar indicadores marginales
        overlayManager.updateProvenanceBadge(stateMachine.currentProvenance.value)
    }

    override fun onInterrupt() {
        // Manejo de degradación: el sistema interrumpió el servicio de accesibilidad
        coordinator.onDegradationOccurred("Servicio de accesibilidad interrumpido por el sistema")
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}`
  },
  {
    path: 'app/src/main/java/com/reelsmetric/overlay/ui/overlay/OverlayWindowManager.kt',
    name: 'OverlayWindowManager.kt',
    package: 'com.reelsmetric.overlay.ui.overlay',
    category: 'UI & Overlay',
    summary: 'Gestor del sello marginal con SYSTEM_ALERT_WINDOW. No interactivo (FLAG_NOT_FOCUSABLE, FLAG_NOT_TOUCHABLE) para no bloquear gestos del usuario.',
    code: `package com.reelsmetric.overlay.ui.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.reelsmetric.overlay.R
import com.reelsmetric.overlay.data.model.ContentProvenance

/**
 * Gestor de Overlay Marginal (Sello no invasivo).
 *
 * Requisitos:
 * 1. Margen superior/lateral discreto.
 * 2. FLAG_NOT_TOUCHABLE y FLAG_NOT_FOCUSABLE para garantizar que ningún toque
 *    o swipe del usuario sobre Instagram sea bloqueado o retardado.
 * 3. Degradación limpia si el permiso no está otorgado.
 */
class OverlayWindowManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var cutsPerSecondTextView: TextView? = null
    private var provenanceBadgeTextView: TextView? = null

    fun showOverlay() {
        if (!Settings.canDrawOverlays(context)) {
            // Degradación: el permiso fue revocado o denegado; omitir sin crash
            return
        }
        if (overlayView != null) return

        val layoutParamsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutParamsType,
            // Clave: No interceptar toques ni foco para que Instagram funcione al 100%
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 80 // Debajo del status bar
        }

        val inflater = LayoutInflater.from(context)
        overlayView = inflater.inflate(R.layout.overlay_metric_pill, null)

        cutsPerSecondTextView = overlayView?.findViewById(R.id.tv_cuts_per_second)
        provenanceBadgeTextView = overlayView?.findViewById(R.id.tv_provenance_badge)

        try {
            windowManager.addView(overlayView, params)
        } catch (e: Exception) {
            // Manejo de excepciones de seguridad
            overlayView = null
        }
    }

    fun updateMetrics(cutsPerSecond: Float) {
        cutsPerSecondTextView?.post {
            cutsPerSecondTextView?.text = String.format("%.1f c/s", cutsPerSecond)
        }
    }

    fun updateProvenanceBadge(provenance: ContentProvenance) {
        provenanceBadgeTextView?.post {
            val label = when (provenance) {
                ContentProvenance.CHOSEN_PROFILE -> "ELEGIDO: Perfil"
                ContentProvenance.CHOSEN_SEARCH -> "ELEGIDO: Búsqueda"
                ContentProvenance.CHOSEN_DIRECT_MESSAGE -> "ELEGIDO: DM"
                ContentProvenance.CHOSEN_EXTERNAL_LINK -> "ELEGIDO: Enlace"
                ContentProvenance.CHOSEN_SAVED_COLLECTION -> "ELEGIDO: Guardados"
                ContentProvenance.PUSHED_REELS_TAB -> "EMPUJADO: Reels Tab"
                ContentProvenance.PUSHED_MAIN_FEED -> "EMPUJADO: Feed"
                ContentProvenance.PUSHED_EXPLORE_GRID_AUTOPLAY -> "EMPUJADO: Explore"
                ContentProvenance.INDETERMINATE -> "ORIGEN: Indeterminado"
            }
            provenanceBadgeTextView?.text = label
        }
    }

    fun hideOverlay() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // Ignore if already removed
            }
            overlayView = null
        }
    }
}`
  }
];

export interface ArchitecturalGap {
  id: string;
  category: 'Android 14/15 Restricción' | 'Accesibilidad & Obfuscación' | 'Heurística de Frames' | 'Ciclo de Vida';
  title: string;
  severity: 'CRÍTICO' | 'ALTO' | 'MEDIO';
  description: string;
  conflictPoint: string;
  architecturalImpact: string;
  recommendedMitigation: string;
}

export const ARCHITECTURAL_GAPS: ArchitecturalGap[] = [
  {
    id: 'GAP-01',
    category: 'Android 14/15 Restricción',
    title: 'Consentimiento MediaProjection de un solo uso (One-Time Consent & Session Revocation)',
    severity: 'CRÍTICO',
    description: 'En Android 14 (API 34) y Android 15 (API 35), el cuadro de diálogo de MediaProjection ya no permite otorgar consentimiento permanente "No volver a preguntar". Además, el sistema puede revocar el token de MediaProjection si la actividad promotora pasa a segundo plano antes de enlazar el ForegroundService.',
    conflictPoint: 'La especificación pide medir continuamente a través de múltiples sesiones de Instagram sin fricción, pero la plataforma exige consentimiento explícito por cada lanzamiento del servicio.',
    architecturalImpact: 'Si el usuario bloquea el teléfono, cambia de app o el ForegroundService se recrea, MediaProjection lanza SecurityException a menos que el usuario vuelva a aceptar el intent desde la MainActivity.',
    recommendedMitigation: 'Implementar el callback MediaProjection.Callback.onStop() con degradación limpia a REVOKED_MID_SESSION en Room y una notificación silenciosa invitando a reanudar la sesión desde la app host.'
  },
  {
    id: 'GAP-02',
    category: 'Accesibilidad & Obfuscación',
    title: 'Fragilidad del Árbol de Accesibilidad por Ofuscación R8/ProGuard en Instagram',
    severity: 'CRÍTICO',
    description: 'Instagram utiliza ofuscación agresiva semanalmente de sus View IDs (resource-ids como "com.instagram.android:id/reel_viewer_title" cambian en cada build de producción) y muchos contenedores de video Reels usan vistas nativas C++ (SurfaceView / TextureView) que reportan nodos vacíos en AccessibilityNodeInfo.',
    conflictPoint: 'La máquina de estados depende de inferir el origen (Perfil vs DM vs Búsqueda vs Tab) a partir de identificadores de nodo de accesibilidad.',
    architecturalImpact: 'En versiones de producción, la máquina de estados fallará frecuentemente al intentar resolver nombres de vistas fijas, degradándose constantemente a INDETERMINATE.',
    recommendedMitigation: 'No basar la inferencia en resource-id fijos. Utilizar cadenas de texto de accesibilidad ("content-description" como "Reels", "Search and explore", "Direct message") o la secuencia de breadcrumbs en la pila de eventos TYPE_WINDOW_STATE_CHANGED.'
  },
  {
    id: 'GAP-03',
    category: 'Heurística de Frames',
    title: 'Falsos Positivos en Cortes de Plano por Elementos Dinámicos de UI y Textos Emergentes',
    severity: 'ALTO',
    description: 'Instagram superpone stickers animados de música, subtítulos autogenerados que cambian palabra por palabra cada 200ms, popups de cuentas recomendadas y animaciones de likes que alteran el histograma global de luminancia aunque el plano cinematográfico de fondo no haya cambiado.',
    conflictPoint: 'El análisis de cortes se basa estrictamente en la diferencia de histograma de luminancia (Y) en una región recortada central sin semántica.',
    architecturalImpact: 'Un reel con subtítulos de alto contraste parpadeantes o zoom digital continuo generará un ritmo artificialmente inflado de 4-8 cortes/segundo.',
    recommendedMitigation: 'Ajustar la región de recorte (Crop Region) al 50% central geométrico y agregar un filtro de supresión de picos de luminancia de duración < 1 frame si la diferencia de histograma es únicamente en altas frecuencias (texto blanco).'
  },
  {
    id: 'GAP-04',
    category: 'Ciclo de Vida',
    title: 'Desincronización Temporal entre Gestos de Swipe y Frames de Video en Buffer',
    severity: 'ALTO',
    description: 'El evento de scroll de accesibilidad se dispara en el hilo de UI de accesibilidad con una latencia distinta a los frames que llegan por el Surface de VirtualDisplay (que operan en el pipeline de SurfaceFlinger a 5 FPS con buffer doble).',
    conflictPoint: 'Al hacer un swipe vertical rápido, el analizador puede procesar 1 o 2 frames de la animación de transición de swipe de Instagram antes de que el nuevo Reel comience su reproducción real.',
    architecturalImpact: 'La transición del swipe puede ser detectada erróneamente como el "primer corte de plano" del nuevo reel.',
    recommendedMitigation: 'Implementar un "Blanking Window" (período de congelación) de 350 ms tras cada onVerticalSwipeDetected() donde los frames se descartan antes de reiniciar la acumulación de histogramas para el nuevo Reel.'
  },
  {
    id: 'GAP-05',
    category: 'Android 14/15 Restricción',
    title: 'Restricción de Captura de Contenido Protegido por DRM o Marcado FLAG_SECURE',
    severity: 'MEDIO',
    description: 'Ciertas transmisiones en vivo o anuncios con DRM dentro de Instagram pueden tener activado FLAG_SECURE en la ventana de SurfaceView.',
    conflictPoint: 'MediaProjection devolverá píxeles completamente negros (RGBA 0,0,0,0) por restricción a nivel de kernel/compositor.',
    architecturalImpact: 'El analizador detectará una caída a cero en el histograma y generará un corte espurio o framerate nulo.',
    recommendedMitigation: 'Detectar frames completamente negros (suma de luminancia < umbral mínimo) y marcar el estado como FRAME_STARVATION sin registrar corte.'
  }
];
