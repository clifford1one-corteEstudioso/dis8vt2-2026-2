import React, { useState } from 'react';
import {
  Layers,
  FileCode,
  Activity,
  Scissors,
  AlertOctagon,
  Download,
  BookOpen,
  Cpu,
  CheckCircle2,
  Shield,
  Smartphone,
  ExternalLink
} from 'lucide-react';
import { FileTreeViewer } from './components/FileTreeViewer';
import { StateMachineSimulator } from './components/StateMachineSimulator';
import { CutAnalyzerSimulator } from './components/CutAnalyzerSimulator';
import { ArchitecturalGapsViewer } from './components/ArchitecturalGapsViewer';
import { PipelineFlowVisualizer } from './components/PipelineFlowVisualizer';

export default function App() {
  const [activeTab, setActiveTab] = useState<'architecture' | 'code' | 'statemachine' | 'analyzer' | 'gaps'>('architecture');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Navigation Header */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-950/40 border border-emerald-400/30">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-bold text-slate-100 tracking-tight">
                  Instagram Reels Overlay Architecture
                </h1>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Android 14/15 Target 35
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono hidden sm:block">
                Ritmo de Cortes (Histograma Y) + Origen Formal (Accessibility State Machine)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono px-2.5 py-1 rounded bg-slate-800 border border-slate-700 hidden md:inline-flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              0% IA / 100% Aritmética Local
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex gap-1 border-t border-slate-850 overflow-x-auto scrollbar-none py-1.5">
          <button
            id="tab-architecture"
            onClick={() => setActiveTab('architecture')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'architecture'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-4 h-4" />
            Visión General & Pipelines
          </button>

          <button
            id="tab-code"
            onClick={() => setActiveTab('code')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'code'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <FileCode className="w-4 h-4" />
            Código Fuente Kotlin & Manifest (8 Archivos)
          </button>

          <button
            id="tab-statemachine"
            onClick={() => setActiveTab('statemachine')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'statemachine'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Activity className="w-4 h-4" />
            Simulador Máquina de Estados
          </button>

          <button
            id="tab-analyzer"
            onClick={() => setActiveTab('analyzer')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'analyzer'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Scissors className="w-4 h-4" />
            Simulador Ritmo de Corte (Histograma Y)
          </button>

          <button
            id="tab-gaps"
            onClick={() => setActiveTab('gaps')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
              activeTab === 'gaps'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : 'text-rose-400/80 hover:text-rose-200 hover:bg-rose-950/40'
            }`}
          >
            <AlertOctagon className="w-4 h-4 text-rose-400" />
            Huecos Arquitectónicos (Crítico)
          </button>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {activeTab === 'architecture' && (
          <div className="space-y-6">
            {/* Executive Summary Card */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-900/60 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs font-bold uppercase tracking-wider">
                <CheckCircle2 className="w-4 h-4" />
                Andamiaje de Arquitectura Nativa Android (Kotlin)
              </div>
              <h2 className="text-xl font-bold text-slate-100">
                Overlay Formal para Instagram Reels: Medición sin Análisis Semántico
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                Este andamiaje resuelve la medición objetiva del <strong>ritmo de cambio de plano</strong> (proxy formal de inducción de estímulos) y la <strong>procedencia del contenido</strong> (rutas elegidas por el usuario vs empujadas por el feed algorítmico). La arquitectura mantiene una estricta segregación de responsabilidades: <em>MediaProjection</em> procesa exclusivamente píxeles a 5 FPS con histogramas de luminancia downscaled a 64x64, mientras <em>AccessibilityService</em> procesa exclusivamente eventos de jerarquía y gestos de navegación, alimentando la persistencia local en <em>Room</em>.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="p-3 bg-slate-950/70 rounded-lg border border-slate-800 text-xs">
                  <span className="text-slate-400 font-semibold block mb-1">Ritmo de Cortes (Shot Cut Rate)</span>
                  <span className="text-slate-200">
                    Muestreo central 4-6 FPS, luminancia ITU-R BT.601, diferencia Chi-cuadrado sobre umbral 0.38 y ventana deslizante de 3 segundos (cortes/s).
                  </span>
                </div>

                <div className="p-3 bg-slate-950/70 rounded-lg border border-slate-800 text-xs">
                  <span className="text-slate-400 font-semibold block mb-1">Máquina de Origen</span>
                  <span className="text-slate-200">
                    Rutas elegidas (Perfil, Búsqueda, DM, Enlace) vs empujadas (Reels Tab, Feed). Reseteo en cada swipe y degradación honesta a INDETERMINATE.
                  </span>
                </div>

                <div className="p-3 bg-slate-950/70 rounded-lg border border-slate-800 text-xs">
                  <span className="text-slate-400 font-semibold block mb-1">Política de Muestreo</span>
                  <span className="text-slate-200">
                    Descarte estricto de huérfanos (&lt;1.5s), ventanas parciales etiquetadas (1.5-3.0s), y guardado inmutable serializable a JSON.
                  </span>
                </div>
              </div>
            </div>

            {/* Pipeline Flow Visualizer */}
            <PipelineFlowVisualizer />

            {/* Quick Link to Architectural Gaps */}
            <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-start gap-3">
                <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-rose-200">
                    Revisión de Factibilidad en Android 14 / 15 (Target SDK 35)
                  </h3>
                  <p className="text-xs text-rose-300/80 mt-0.5">
                    Se han identificado 5 huecos arquitectónicos críticos: revocación de MediaProjection, ofuscación R8 en Instagram, textos flotantes y desfase de frames.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('gaps')}
                className="px-4 py-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 rounded-lg text-xs font-semibold border border-rose-500/40 whitespace-nowrap transition-colors"
              >
                Ver Análisis Completo de Huecos →
              </button>
            </div>
          </div>
        )}

        {activeTab === 'code' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-100">
                  Estructura de Paquetes y Esqueletos de Código Kotlin
                </h2>
                <p className="text-xs text-slate-400">
                  Código compilable con firmas completas, anotaciones Room, Service Types de Android 14/15 y comentarios TODO en lógica no trivial.
                </p>
              </div>
            </div>
            <FileTreeViewer />
          </div>
        )}

        {activeTab === 'statemachine' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100">
                Simulador Interactivo de la Máquina de Estados de Origen
              </h2>
              <p className="text-xs text-slate-400">
                Prueba cómo el componente <code>OriginTrackerStateMachine</code> reacciona a los eventos de UI y gestos de scroll.
              </p>
            </div>
            <StateMachineSimulator />
          </div>
        )}

        {activeTab === 'analyzer' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100">
                Simulador de Detección de Cortes por Histograma de Luminancia
              </h2>
              <p className="text-xs text-slate-400">
                Motor aritmético en tiempo real sobre frames downscaled a 64x64 sin modelos de IA.
              </p>
            </div>
            <CutAnalyzerSimulator />
          </div>
        )}

        {activeTab === 'gaps' && (
          <div className="space-y-4">
            <ArchitecturalGapsViewer />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-4 text-center text-xs text-slate-500 font-mono">
        Instagram Reels Formal Metrics Scaffolding • MinSdk 29 • TargetSdk 35 • Android Architecture Blueprint
      </footer>
    </div>
  );
}
