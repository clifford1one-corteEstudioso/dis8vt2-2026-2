import React, { useState } from 'react';
import { Play, RotateCcw, ArrowRight, Activity, ShieldCheck, AlertTriangle } from 'lucide-react';

export const StateMachineSimulator: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<string>('OutOfInstagram');
  const [provenance, setProvenance] = useState<string>('INDETERMINATE');
  const [category, setCategory] = useState<'CHOSEN' | 'PUSHED' | 'UNKNOWN'>('UNKNOWN');
  const [swipeCount, setSwipeCount] = useState<number>(0);
  const [dwellTimeMs, setDwellTimeMs] = useState<number>(3400);
  const [logs, setLogs] = useState<Array<{ time: string; event: string; provenance: string; validity: string }>>([
    {
      time: '00:00.000',
      event: 'Inicialización de máquina de estados',
      provenance: 'INDETERMINATE',
      validity: 'STANDBY'
    }
  ]);

  const addLog = (event: string, prov: string, val: string) => {
    const timeStr = new Date().toISOString().substring(14, 22);
    setLogs(prev => [{ time: timeStr, event, provenance: prov, validity: val }, ...prev.slice(0, 15)]);
  };

  const handleAction = (action: string) => {
    switch (action) {
      case 'OPEN_PROFILE_REEL':
        setCurrentScreen('ActiveReelViewer');
        setProvenance('CHOSEN_PROFILE');
        setCategory('CHOSEN');
        setSwipeCount(0);
        addLog('Usuario entra a perfil y toca Reel (Ruta Elegida)', 'CHOSEN_PROFILE', 'VALID');
        break;

      case 'OPEN_SEARCH_REEL':
        setCurrentScreen('ActiveReelViewer');
        setProvenance('CHOSEN_SEARCH');
        setCategory('CHOSEN');
        setSwipeCount(0);
        addLog('Usuario busca hashtag/audio y abre Reel', 'CHOSEN_SEARCH', 'VALID');
        break;

      case 'OPEN_DM_REEL':
        setCurrentScreen('ActiveReelViewer');
        setProvenance('CHOSEN_DIRECT_MESSAGE');
        setCategory('CHOSEN');
        setSwipeCount(0);
        addLog('Usuario toca reel compartido en DM', 'CHOSEN_DIRECT_MESSAGE', 'VALID');
        break;

      case 'OPEN_REELS_TAB':
        setCurrentScreen('ActiveReelViewer');
        setProvenance('PUSHED_REELS_TAB');
        setCategory('PUSHED');
        setSwipeCount(0);
        addLog('Usuario toca pestaña inferior Reels (Ruta Empujada)', 'PUSHED_REELS_TAB', 'VALID');
        break;

      case 'SWIPE_VERTICAL':
        if (currentScreen === 'ActiveReelViewer') {
          const nextCount = swipeCount + 1;
          setSwipeCount(nextCount);
          // Si venía de CHOSEN, el swipe vertical transiciona a PUSHED porque el algoritmo toma el control
          const nextProv = category === 'CHOSEN' ? 'PUSHED_REELS_TAB' : provenance;
          const nextCat = 'PUSHED';
          setProvenance(nextProv);
          setCategory(nextCat);
          const validity = dwellTimeMs < 1500 ? 'SHORT_DWELL_DISCARDED' : dwellTimeMs < 3000 ? 'PARTIAL_WINDOW' : 'VALID';
          addLog(`Swipe vertical #${nextCount} (Reset de histograma + nueva sesión)`, nextProv, validity);
        } else {
          addLog('Swipe fuera de visor activo -> Degradación', 'INDETERMINATE', 'UNKNOWN');
        }
        break;

      case 'FAST_SWIPE_ORPHAN':
        if (currentScreen === 'ActiveReelViewer') {
          setSwipeCount(prev => prev + 1);
          setProvenance('PUSHED_REELS_TAB');
          setCategory('PUSHED');
          addLog('Swipe rápido (<1.5s): Muestreo Huérfano descartado sin contaminar siguiente reel', 'PUSHED_REELS_TAB', 'SHORT_DWELL_DISCARDED');
        }
        break;

      case 'APP_BACKGROUND':
        setCurrentScreen('OutOfInstagram');
        setProvenance('INDETERMINATE');
        setCategory('UNKNOWN');
        setSwipeCount(0);
        addLog('Instagram pasa a segundo plano / Cerrado abruptamente', 'INDETERMINATE', 'FRAME_STARVATION');
        break;

      case 'RESET':
        setCurrentScreen('OutOfInstagram');
        setProvenance('INDETERMINATE');
        setCategory('UNKNOWN');
        setSwipeCount(0);
        setLogs([{ time: '00:00.000', event: 'Reset manual', provenance: 'INDETERMINATE', validity: 'STANDBY' }]);
        break;
    }
  };

  return (
    <div id="state-machine-simulator" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            Simulador de Máquina de Estados de Origen (OriginTrackerStateMachine)
          </h3>
          <p className="text-xs text-slate-400">
            Prueba cómo la máquina clasifica rutas elegidas (Pull) vs empujadas (Push) y cómo degrada honestamente a INDETERMINATE.
          </p>
        </div>
        <button
          onClick={() => handleAction('RESET')}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-700 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset
        </button>
      </div>

      {/* State Dashboard Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium">Estado Actual UI</span>
          <div className="text-sm font-mono font-bold text-slate-200 mt-1 truncate">
            {currentScreen}
          </div>
          <span className="text-[10px] text-slate-500">
            {currentScreen === 'ActiveReelViewer' ? `Swipes en cadena: ${swipeCount}` : 'Sin visor activo'}
          </span>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium">Origen Inferido</span>
          <div className="text-sm font-mono font-bold text-emerald-400 mt-1 truncate">
            {provenance}
          </div>
          <span className="text-[10px] text-slate-500">Clase ContentProvenance</span>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium">Categoría Formal</span>
          <div className="mt-1">
            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-semibold ${
              category === 'CHOSEN'
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                : category === 'PUSHED'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'bg-slate-700/40 text-slate-400 border border-slate-700'
            }`}>
              {category === 'CHOSEN' && <ShieldCheck className="w-3 h-3" />}
              {category === 'UNKNOWN' && <AlertTriangle className="w-3 h-3" />}
              {category}
            </span>
          </div>
          <span className="text-[10px] text-slate-500">Elegido vs Empujado</span>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium">Simulador Permanencia</span>
          <div className="flex items-center gap-2 mt-1">
            <input
              type="range"
              min="500"
              max="6000"
              step="100"
              value={dwellTimeMs}
              onChange={(e) => setDwellTimeMs(Number(e.target.value))}
              className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <span className="text-xs font-mono text-slate-300 w-12 text-right">{(dwellTimeMs / 1000).toFixed(1)}s</span>
          </div>
          <span className="text-[10px] text-slate-500">
            {dwellTimeMs < 1500 ? 'Descarta huérfano' : dwellTimeMs < 3000 ? 'Ventana parcial' : 'Ventana válida (>=3s)'}
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2">
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wide">
          Disparar Eventos de Navegación (AccessibilityService):
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
          <button
            onClick={() => handleAction('OPEN_PROFILE_REEL')}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 text-xs font-medium text-left transition-colors"
          >
            <div className="font-semibold text-blue-300">1. Clic Perfil</div>
            <div className="text-[10px] text-slate-400">CHOSEN_PROFILE</div>
          </button>

          <button
            onClick={() => handleAction('OPEN_SEARCH_REEL')}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 text-xs font-medium text-left transition-colors"
          >
            <div className="font-semibold text-blue-300">2. Clic Búsqueda</div>
            <div className="text-[10px] text-slate-400">CHOSEN_SEARCH</div>
          </button>

          <button
            onClick={() => handleAction('OPEN_DM_REEL')}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 text-xs font-medium text-left transition-colors"
          >
            <div className="font-semibold text-blue-300">3. Clic en DM</div>
            <div className="text-[10px] text-slate-400">CHOSEN_DIRECT_MESSAGE</div>
          </button>

          <button
            onClick={() => handleAction('OPEN_REELS_TAB')}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 text-xs font-medium text-left transition-colors"
          >
            <div className="font-semibold text-amber-300">4. Tab Reels</div>
            <div className="text-[10px] text-slate-400">PUSHED_REELS_TAB</div>
          </button>

          <button
            onClick={() => handleAction('SWIPE_VERTICAL')}
            className="p-2 bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-200 rounded-lg border border-emerald-500/30 text-xs font-medium text-left transition-colors"
          >
            <div className="font-semibold text-emerald-300">5. Swipe Vertical</div>
            <div className="text-[10px] text-emerald-400">Reset + Algoritmo</div>
          </button>

          <button
            onClick={() => handleAction('APP_BACKGROUND')}
            className="p-2 bg-rose-950/30 hover:bg-rose-900/40 text-rose-200 rounded-lg border border-rose-500/30 text-xs font-medium text-left transition-colors"
          >
            <div className="font-semibold text-rose-300">6. Salir / App BG</div>
            <div className="text-[10px] text-rose-400">INDETERMINATE</div>
          </button>
        </div>
      </div>

      {/* Live Event Log */}
      <div className="bg-slate-950 rounded-lg border border-slate-800 p-3">
        <span className="text-[11px] font-mono font-medium text-slate-400 block mb-2">
          Registro de Transiciones en Tiempo Real:
        </span>
        <div className="space-y-1.5 max-h-36 overflow-y-auto font-mono text-[11px]">
          {logs.map((log, index) => (
            <div key={index} className="flex items-center gap-2 text-slate-300 border-b border-slate-900/60 pb-1">
              <span className="text-slate-500">{log.time}</span>
              <span className="text-slate-200 flex-1 truncate">{log.event}</span>
              <span className="text-emerald-400 font-semibold px-1.5 py-0.5 rounded bg-emerald-950/50 text-[10px]">
                {log.provenance}
              </span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                log.validity === 'VALID' ? 'bg-blue-900/40 text-blue-300' :
                log.validity === 'SHORT_DWELL_DISCARDED' ? 'bg-rose-900/40 text-rose-300' : 'bg-slate-800 text-slate-400'
              }`}>
                {log.validity}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
