import React, { useState } from 'react';
import { ARCHITECTURAL_GAPS, ArchitecturalGap } from '../data/architectureData';
import { AlertOctagon, AlertTriangle, ShieldAlert, Cpu, Wrench, FileSearch } from 'lucide-react';

export const ArchitecturalGapsViewer: React.FC = () => {
  const [selectedGap, setSelectedGap] = useState<ArchitecturalGap>(ARCHITECTURAL_GAPS[0]);

  return (
    <div id="architectural-gaps-section" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5">
      <div className="border-b border-slate-800 pb-3 flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-rose-500/20 border border-rose-500/30 text-rose-400">
              <AlertOctagon className="w-4 h-4" />
            </span>
            <h2 className="text-base font-bold text-slate-100 uppercase tracking-wide">
              Sección Especial: Huecos Arquitectónicos & Conflictos con Android 14 / 15
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Análisis crítico formal de puntos donde la especificación no cierra, presenta ambigüedad o colisiona frontalmente con el sistema operativo.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Gap List */}
        <div className="lg:col-span-5 space-y-2">
          {ARCHITECTURAL_GAPS.map((gap) => {
            const isSelected = selectedGap.id === gap.id;
            return (
              <button
                key={gap.id}
                onClick={() => setSelectedGap(gap)}
                className={`w-full text-left p-3 rounded-lg border transition-all flex flex-col gap-1.5 ${
                  isSelected
                    ? 'bg-slate-800 border-rose-500/60 shadow-lg shadow-rose-950/20'
                    : 'bg-slate-950/50 border-slate-800/80 hover:bg-slate-850 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    {gap.id}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                    gap.severity === 'CRÍTICO'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : gap.severity === 'ALTO'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                  }`}>
                    {gap.severity}
                  </span>
                </div>
                <h4 className="text-xs font-semibold text-slate-200 line-clamp-1">
                  {gap.title}
                </h4>
                <span className="text-[11px] text-slate-400 font-mono">
                  {gap.category}
                </span>
              </button>
            );
          })}
        </div>

        {/* Gap Detailed Analysis */}
        <div className="lg:col-span-7 bg-slate-950/80 rounded-lg border border-slate-800 p-4 flex flex-col space-y-4">
          <div className="border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono text-rose-400 font-bold">{selectedGap.id}</span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {selectedGap.category}
              </span>
            </div>
            <h3 className="text-sm font-bold text-slate-100">
              {selectedGap.title}
            </h3>
          </div>

          <div className="space-y-3 text-xs leading-relaxed">
            <div>
              <span className="text-slate-400 font-semibold uppercase text-[10px] tracking-wider block mb-0.5 flex items-center gap-1">
                <FileSearch className="w-3.5 h-3.5 text-blue-400" />
                Naturaleza de la Fricción:
              </span>
              <p className="text-slate-300 bg-slate-900/60 p-2.5 rounded border border-slate-800/80">
                {selectedGap.description}
              </p>
            </div>

            <div>
              <span className="text-amber-400 font-semibold uppercase text-[10px] tracking-wider block mb-0.5 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                Punto de Conflicto con la Especificación:
              </span>
              <p className="text-slate-300 bg-amber-950/20 p-2.5 rounded border border-amber-500/20 text-amber-200/90">
                {selectedGap.conflictPoint}
              </p>
            </div>

            <div>
              <span className="text-rose-400 font-semibold uppercase text-[10px] tracking-wider block mb-0.5 flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5 text-rose-400" />
                Impacto en el Prototipo:
              </span>
              <p className="text-slate-300 bg-rose-950/20 p-2.5 rounded border border-rose-500/20 text-rose-200/90">
                {selectedGap.architecturalImpact}
              </p>
            </div>

            <div>
              <span className="text-emerald-400 font-semibold uppercase text-[10px] tracking-wider block mb-0.5 flex items-center gap-1">
                <Wrench className="w-3.5 h-3.5 text-emerald-400" />
                Mitigación Arquitectónica Recomendada:
              </span>
              <p className="text-emerald-300/90 bg-emerald-950/20 p-2.5 rounded border border-emerald-500/20 font-medium">
                {selectedGap.recommendedMitigation}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
