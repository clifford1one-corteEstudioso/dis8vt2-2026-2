import React from 'react';
import { Camera, Eye, Layers, Database, Sparkles, Sliders, Shield, ArrowDown, Activity } from 'lucide-react';

export const PipelineFlowVisualizer: React.FC = () => {
  return (
    <div id="pipeline-flow-visualizer" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5">
      <div className="border-b border-slate-800 pb-3">
        <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-400" />
          Arquitectura de Datos Desacoplada (2 Canales Estrictamente Separados)
        </h3>
        <p className="text-xs text-slate-400">
          Ninguna fuente se mezcla: MediaProjection es la única fuente de píxeles, AccessibilityService es la única fuente de UI.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Pipeline 1: Video Capture & Arithmetic */}
        <div className="bg-slate-950/70 border border-rose-500/30 rounded-xl p-4 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
                <Camera className="w-4 h-4" />
              </span>
              <div>
                <h4 className="text-xs font-bold text-slate-200 uppercase">Canal 1: MediaProjection</h4>
                <span className="text-[10px] text-rose-400 font-mono">Única fuente de píxeles (0% IA)</span>
              </div>
            </div>
            <span className="text-[10px] bg-rose-950/60 text-rose-300 border border-rose-800 px-2 py-0.5 rounded font-mono">
              Foreground Service
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">1. VirtualDisplay + ImageReader</span>
              <span className="text-emerald-400 font-bold">5 FPS (200ms)</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">2. Recorte Central Geométrico</span>
              <span className="text-amber-400">Omite UI/Textos</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">3. Downscale Agresivo</span>
              <span className="text-blue-400">64 x 64 px</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">4. Histograma Luminancia (BT.601 Y)</span>
              <span className="text-purple-400">32 Bins normalizados</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-rose-950/30 border border-rose-500/40 flex items-center justify-between text-rose-300">
              <span>5. Comparación ΔH &gt;= 0.38</span>
              <span className="font-bold">Ventana 3s → Cortes/s</span>
            </div>
          </div>
        </div>

        {/* Pipeline 2: Accessibility & State Machine */}
        <div className="bg-slate-950/70 border border-blue-500/30 rounded-xl p-4 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400">
                <Eye className="w-4 h-4" />
              </span>
              <div>
                <h4 className="text-xs font-bold text-slate-200 uppercase">Canal 2: AccessibilityService</h4>
                <span className="text-[10px] text-blue-400 font-mono">Única fuente de UI y Gestos</span>
              </div>
            </div>
            <span className="text-[10px] bg-blue-950/60 text-blue-300 border border-blue-800 px-2 py-0.5 rounded font-mono">
              AccessibilityNodeInfo
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono">
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">1. Filtro com.instagram.android</span>
              <span className="text-emerald-400 font-bold">TYPE_WINDOW_STATE</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">2. Detección de Contexto Previo</span>
              <span className="text-amber-400">Perfil / DM / Search / Feed</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">3. Detector de Swipe Vertical</span>
              <span className="text-blue-400">TYPE_VIEW_SCROLLED</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-300">4. Máquina de Estados de Origen</span>
              <span className="text-purple-400">Elegido vs Empujado</span>
            </div>
            <div className="flex justify-center text-slate-600">↓</div>
            <div className="p-2 rounded bg-blue-950/30 border border-blue-500/40 flex items-center justify-between text-blue-300">
              <span>5. Fallback Honesto</span>
              <span className="font-bold">INDETERMINATE en ambigüedad</span>
            </div>
          </div>
        </div>
      </div>

      {/* Junction: Sampling Coordinator & Outputs */}
      <div className="bg-slate-950/90 border border-emerald-500/40 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <span className="p-1 rounded bg-emerald-500/20 text-emerald-400">
              <Activity className="w-4 h-4" />
            </span>
            <h4 className="text-xs font-bold text-slate-100 uppercase">
              Coordinador de Sesión y Política de Muestreo (SamplingSessionCoordinator)
            </h4>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">Dwell Time Management</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs font-mono">
          <div className="p-2.5 rounded bg-rose-950/20 border border-rose-500/30 text-rose-300">
            <span className="font-bold block text-rose-400 mb-0.5">&lt; 1500 ms (Huérfano)</span>
            <span className="text-[11px] text-slate-400">Swipe rápido: Se descarta la medición. No contamina el siguiente reel.</span>
          </div>

          <div className="p-2.5 rounded bg-amber-950/20 border border-amber-500/30 text-amber-300">
            <span className="font-bold block text-amber-400 mb-0.5">1500 - 3000 ms (Parcial)</span>
            <span className="text-[11px] text-slate-400">Ventana incompleta: Se guarda con flag PARTIAL_WINDOW.</span>
          </div>

          <div className="p-2.5 rounded bg-emerald-950/20 border border-emerald-500/30 text-emerald-300">
            <span className="font-bold block text-emerald-400 mb-0.5">&gt;= 3000 ms (Válida)</span>
            <span className="text-[11px] text-slate-400">Cumplió ventana de 3s: Guardado formal Room con flag VALID.</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
          <div className="p-2 bg-slate-900 rounded border border-slate-800 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-blue-400" />
              Persistencia Room (SQLite)
            </span>
            <span className="text-slate-400 text-[11px]">ReelMeasurementEntity</span>
          </div>
          <div className="p-2 bg-slate-900 rounded border border-slate-800 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              SYSTEM_ALERT_WINDOW
            </span>
            <span className="text-slate-400 text-[11px]">FLAG_NOT_TOUCHABLE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
