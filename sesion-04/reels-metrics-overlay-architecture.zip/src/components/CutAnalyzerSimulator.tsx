import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RefreshCw, Scissors, Film, Gauge, Sliders } from 'lucide-react';

export const CutAnalyzerSimulator: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [fps, setFps] = useState(5); // 4-6 FPS
  const [threshold, setThreshold] = useState(0.38); // 0.38 configurable
  const [windowSec, setWindowSec] = useState(3.0); // 3s sliding window
  const [cutsPerSec, setCutsPerSec] = useState(0.0);
  const [totalCuts, setTotalCuts] = useState(0);
  const [currentDiff, setCurrentDiff] = useState(0.0);
  const [lastCutTime, setLastCutTime] = useState<string>('Ninguno');
  const [frameHistory, setFrameHistory] = useState<Array<{ id: number; diff: number; isCut: boolean; luma: number }>>([]);

  const cutsTimestampsRef = useRef<number[]>([]);
  const frameCountRef = useRef<number>(0);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isRunning) {
      const intervalMs = Math.round(1000 / fps);
      interval = setInterval(() => {
        const now = Date.now();
        frameCountRef.current += 1;

        // Generar un cambio de luminancia estocástico (con probabilidad de corte repentino del 20%)
        const willCut = Math.random() < 0.18;
        const diff = willCut
          ? threshold + Math.random() * 0.4
          : Math.random() * (threshold * 0.7);

        const luma = Math.round(40 + Math.random() * 180);
        setCurrentDiff(Number(diff.toFixed(3)));

        const isCut = diff >= threshold;
        if (isCut) {
          cutsTimestampsRef.current.push(now);
          setTotalCuts(prev => prev + 1);
          setLastCutTime(new Date().toISOString().substring(17, 22));
        }

        // Purgar ventana deslizante de 3s
        const cutoff = now - (windowSec * 1000);
        cutsTimestampsRef.current = cutsTimestampsRef.current.filter(t => t >= cutoff);

        // Cortes por segundo puros = cantidad de cortes en la ventana / segundos de la ventana
        const calculatedRate = cutsTimestampsRef.current.length / windowSec;
        setCutsPerSec(Number(calculatedRate.toFixed(2)));

        setFrameHistory(prev => [
          { id: frameCountRef.current, diff: Number(diff.toFixed(3)), isCut, luma },
          ...prev.slice(0, 18)
        ]);

      }, intervalMs);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, fps, threshold, windowSec]);

  const handleReset = () => {
    setIsRunning(false);
    cutsTimestampsRef.current = [];
    frameCountRef.current = 0;
    setCutsPerSec(0.0);
    setTotalCuts(0);
    setCurrentDiff(0.0);
    setLastCutTime('Ninguno');
    setFrameHistory([]);
  };

  return (
    <div id="cut-analyzer-simulator" className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5">
      <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 gap-2">
        <div>
          <h3 className="text-base font-semibold text-slate-100 flex items-center gap-2">
            <Scissors className="w-4 h-4 text-rose-400" />
            Simulador de Ritmo de Corte (ShotCutAnalyzer - Histograma de Luminancia)
          </h3>
          <p className="text-xs text-slate-400">
            Aritmética estricta sobre frames downscaled a 64x64 a 4-6 FPS. Sin IA, sin redes neuronales.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              isRunning
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
            }`}
          >
            {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            {isRunning ? 'Pausar Muestreo' : 'Iniciar Muestreo (5 FPS)'}
          </button>
          <button
            onClick={handleReset}
            className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 bg-slate-800 px-2.5 py-1.5 rounded-lg border border-slate-700 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Reset
          </button>
        </div>
      </div>

      {/* Main Metrics KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium flex items-center gap-1">
            <Gauge className="w-3.5 h-3.5 text-rose-400" />
            Ritmo de Corte
          </span>
          <div className="text-2xl font-mono font-bold text-rose-400 mt-1">
            {cutsPerSec} <span className="text-xs font-sans text-slate-400">cortes/s</span>
          </div>
          <span className="text-[10px] text-slate-500">Ventana activa ({windowSec}s)</span>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium flex items-center gap-1">
            <Film className="w-3.5 h-3.5 text-blue-400" />
            Diferencia de Histograma (ΔH)
          </span>
          <div className="text-2xl font-mono font-bold text-slate-200 mt-1">
            {currentDiff}
          </div>
          <span className={`text-[10px] font-semibold ${currentDiff >= threshold ? 'text-rose-400' : 'text-emerald-400'}`}>
            {currentDiff >= threshold ? '¡CORTE DE PLANO DETECTADO!' : 'Continuidad visual'}
          </span>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium">Total Cortes en Sesión</span>
          <div className="text-2xl font-mono font-bold text-slate-200 mt-1">
            {totalCuts}
          </div>
          <span className="text-[10px] text-slate-500">Último corte: {lastCutTime}</span>
        </div>

        <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase font-medium">Pipeline Downscale</span>
          <div className="text-sm font-mono font-bold text-slate-200 mt-1">
            64 x 64 px @ {fps} FPS
          </div>
          <span className="text-[10px] text-emerald-400">ITU-R BT.601 (Y) Luma</span>
        </div>
      </div>

      {/* Sliders & Controls */}
      <div className="bg-slate-950/60 p-3.5 rounded-lg border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <div className="flex justify-between text-xs text-slate-300 mb-1">
            <span>Frecuencia de Muestreo (FPS)</span>
            <span className="font-mono text-emerald-400">{fps} fps</span>
          </div>
          <input
            type="range"
            min="3"
            max="10"
            step="1"
            value={fps}
            onChange={(e) => setFps(Number(e.target.value))}
            className="w-full accent-emerald-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-slate-500">Restricción especificada: 4 a 6 FPS</span>
        </div>

        <div>
          <div className="flex justify-between text-xs text-slate-300 mb-1">
            <span>Umbral de Corte (ΔH Threshold)</span>
            <span className="font-mono text-rose-400">{threshold.toFixed(2)}</span>
          </div>
          <input
            type="range"
            min="0.15"
            max="0.80"
            step="0.01"
            value={threshold}
            onChange={(e) => setThreshold(Number(e.target.value))}
            className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-slate-500">Constante configurable expuesta</span>
        </div>

        <div>
          <div className="flex justify-between text-xs text-slate-300 mb-1">
            <span>Duración Ventana Deslizante</span>
            <span className="font-mono text-blue-400">{windowSec.toFixed(1)}s</span>
          </div>
          <input
            type="range"
            min="1.0"
            max="6.0"
            step="0.5"
            value={windowSec}
            onChange={(e) => setWindowSec(Number(e.target.value))}
            className="w-full accent-blue-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
          />
          <span className="text-[10px] text-slate-500">Ventana deslizante estándar: 3.0 s</span>
        </div>
      </div>

      {/* Frame Timeline visualization */}
      <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
        <span className="text-[11px] font-mono font-medium text-slate-400 block mb-2">
          Línea Temporal de Frames y Disparos de Corte (Últimos 18 frames):
        </span>
        <div className="grid grid-cols-9 md:grid-cols-18 gap-1.5">
          {frameHistory.map((f) => (
            <div
              key={f.id}
              className={`p-1.5 rounded flex flex-col items-center justify-between h-20 text-[10px] font-mono border transition-all ${
                f.isCut
                  ? 'bg-rose-950/60 border-rose-500 text-rose-200 font-bold shadow-lg shadow-rose-950/50'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}
            >
              <span className="text-[9px] text-slate-500">#{f.id}</span>
              <div
                className="w-full rounded h-6"
                style={{ backgroundColor: `rgb(${f.luma}, ${f.luma}, ${f.luma})` }}
                title={`Luma: ${f.luma}`}
              />
              <span className={f.isCut ? 'text-rose-400 font-bold' : 'text-slate-500'}>
                {f.isCut ? 'CORTE' : f.diff}
              </span>
            </div>
          ))}
          {frameHistory.length === 0 && (
            <div className="col-span-full text-center text-xs text-slate-500 py-6">
              Presiona "Iniciar Muestreo" para simular la captura continua de frames y detección de cortes.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
