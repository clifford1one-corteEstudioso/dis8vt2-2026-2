import React, { useState } from 'react';
import { ARCHITECTURE_FILES, KotlinFileDef } from '../data/architectureData';
import { FileCode, Copy, Check, Terminal, Layers } from 'lucide-react';

export const FileTreeViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<KotlinFileDef>(ARCHITECTURE_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = ['ALL', 'Manifest & Config', 'Service', 'Domain & Algoritmos', 'State Machine', 'Data & Persistence', 'UI & Overlay'];

  const filteredFiles = selectedCategory === 'ALL'
    ? ARCHITECTURE_FILES
    : ARCHITECTURE_FILES.filter(f => f.category === selectedCategory);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="file-tree-viewer-container" className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col h-[750px]">
      {/* Top bar */}
      <div id="file-viewer-header" className="bg-slate-950/80 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="text-sm font-mono font-medium text-slate-200">
            {selectedFile.path}
          </span>
          <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 font-sans">
            {selectedFile.category}
          </span>
        </div>
        <button
          id="btn-copy-code"
          onClick={handleCopy}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
          <span>{copied ? 'Copiado al portapapeles' : 'Copiar archivo'}</span>
        </button>
      </div>

      {/* Main split */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Sidebar file list */}
        <div id="file-sidebar" className="w-full md:w-80 bg-slate-950/60 border-r border-slate-800 flex flex-col overflow-hidden">
          {/* Category filter tabs */}
          <div className="p-2 border-b border-slate-800/80 flex gap-1 overflow-x-auto text-xs scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2 py-1 rounded whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                {cat === 'ALL' ? 'Todos' : cat}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex flex-col gap-1 ${
                    isSelected
                      ? 'bg-slate-800 text-white border border-emerald-500/40 shadow-sm'
                      : 'text-slate-400 hover:bg-slate-850 hover:text-slate-200 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <span className="font-mono text-xs font-semibold truncate text-slate-100">{file.name}</span>
                  </div>
                  <span className="text-[11px] text-slate-400 line-clamp-1 pl-6">
                    {file.summary}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Code view area */}
        <div id="code-content-area" className="flex-1 flex flex-col overflow-hidden bg-slate-900">
          <div className="p-3 bg-slate-900 border-b border-slate-800 text-xs text-slate-400 flex items-center justify-between">
            <span>{selectedFile.summary}</span>
            <span className="font-mono text-[11px] text-slate-500">Package: {selectedFile.package}</span>
          </div>
          <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-300 leading-relaxed">
            <pre className="whitespace-pre">
              <code>{selectedFile.code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
